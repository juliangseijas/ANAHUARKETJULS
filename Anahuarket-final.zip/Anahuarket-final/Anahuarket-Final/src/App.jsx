import { BrowserRouter, Route, Routes } from "react-router-dom";
import Login from "./pages/LogIn";
import Registro from "./pages/Registro";
import Home from "./pages/Home";
import Perfil from "./pages/Perfil";


function App() {
  return (
  <BrowserRouter>
  <Routes>
    <Route path="/" element={<Login/>}/>
    <Route path="/registro" element={<Registro/>}/>
    <Route path="/home" element={<Home/>}/>
    <Route path="/perfil" element ={<Perfil/>}/>
  </Routes>
  </BrowserRouter>
  )
}

export default App
