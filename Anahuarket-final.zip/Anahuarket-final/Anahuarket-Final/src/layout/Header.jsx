import "../assets/styles/global.css";

function Header() {
  return (
    <>
      <header>
        <div className="top-bar">
          <h1 className="logo">INICIO</h1>
          <div className="icons-right">
            <a href="/home">
              <svg
                xmlns="http://www.w3.org/2000/svg"
                width={40}
                height={40}
                fill="#F28901"
                className="bi bi-house-door-fill"
                viewBox="0 0 16 16"
              >
                <path d="M6.5 14.5v-3.505c0-.245.25-.495.5-.495h2c.25 0 .5.25.5.5v3.5a.5.5 0 0 0 .5.5h4a.5.5 0 0 0 .5-.5v-7a.5.5 0 0 0-.146-.354L13 5.793V2.5a.5.5 0 0 0-.5-.5h-1a.5.5 0 0 0-.5.5v1.293L8.354 1.146a.5.5 0 0 0-.708 0l-6 6A.5.5 0 0 0 1.5 7.5v7a.5.5 0 0 0 .5.5h4a.5.5 0 0 0 .5-.5" />
              </svg>
            </a>
            <div className="notification-icon">
              <svg
                xmlns="http://www.w3.org/2000/svg"
                width={40}
                height={40}
                className="bi bi-envelope-fill"
                viewBox="0 0 16 16"
              >
                <path
                  fill="#F28901"
                  d="M.05 3.555A2 2 0 0 1 2 2h12a2 2 0 0 1 1.95 1.555L8 8.414zM0 4.697v7.104l5.803-3.558zM6.761 8.83l-6.57 4.027A2 2 0 0 0 2 14h12a2 2 0 0 0 1.808-1.144l-6.57-4.027L8 9.586zm3.436-.586L16 11.801V4.697z"
                />
              </svg>
              <div className="notification-dropdown">
                <div className="notification-item">
                  <p className="noti-title">Pepito Castillo Beckham</p>
                  <p className="noti-text">Inició un proceso de compra</p>
                  <p className="noti-product">iPhone 13 - $7,500.00</p>
                  <small>31/02/2025 - 18:18</small>
                </div>
              </div>
            </div>
            <a href="/perfil">
              <svg
                xmlns="http://www.w3.org/2000/svg"
                width={40}
                height={40}
                fill="#F28901"
                className="bi bi-person-fill"
                viewBox="0 0 16 16"
              >
                <path d="M3 14s-1 0-1-1 1-4 6-4 6 3 6 4-1 1-1 1zm5-6a3 3 0 1 0 0-6 3 3 0 0 0 0 6" />
              </svg>
            </a>
          </div>
        </div>
      </header>
    </>
  );
}

export default Header;
