import styles from "../assets/styles/login-registro.module.css";

function Login() {
  return (
    <div className={styles.wrapper}>
      <header>
        <h1 className={styles.InicioSesion}>INICIAR SESIÓN</h1>
      </header>
      <main>
        <h2>¡¡BIENVENID@!!</h2>
        <div className={styles.fotoAnahuac} />
          <div className={styles.containerLogin}>
          <form id="loginForm" action="/home">
            <input type="email" placeholder="user@anahuac.mx" required="" />
            <input type="password" placeholder="Contraseña" required="" />
            <div className={styles.buttons}>
              <a href="/registro">
                <button type="button" id="registerBtn">
                  REGISTRARSE
                </button>
              </a>
              <button type="submit">SIGUIENTE</button>
            </div>
          </form>
        </div>
      </main>
      <footer>
        <p className={styles.note}>Recuerda ingresar con tu correo institucional</p>
      </footer>
    </div>
  );
}

export default Login;
