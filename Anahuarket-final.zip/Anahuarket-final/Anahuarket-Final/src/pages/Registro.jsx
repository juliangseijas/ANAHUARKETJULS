import styles from "../assets/styles/login-registro.module.css";

function Registro() {
  return (
    <div className={styles.wrapper}>
      <header>
        <h1 className={styles.InicioSesion}>REGISTRATE</h1>
      </header>
      <main>
        <div className={styles.fotoAnahuac} />
        <h2>¡¡BIENVENID@!!</h2>
        <div className={styles.containerLogin}>
          <form id="loginForm" action="/home">
            <input type="email" placeholder="user@anahuac.mx" required="" />
            <input type="password" placeholder="Contraseña" required="" />
            <div className={styles.botonRegistroSiguiente}>
              <button type="submit">SIGUIENTE</button>
            </div>
          </form>
        </div>
      </main>
      <footer>
        <p className={styles.note}>
          Recuerda registrate con tu correo institucional
        </p>
      </footer>
    </div>
  );
}

export default Registro;
